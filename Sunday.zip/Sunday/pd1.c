#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char seq[ 1000 ];
	int len;
	int i;
	int charge = 0;

	scanf("%s", seq);
	len = strlen( seq );
	printf("The length was : %d \n", len);

		if (len < 3)
		{
			printf("Eisai boubounas!!!\n");
		}
		
		if( seq[ 0 ] == 'A' && seq[ 1 ] == 'T' && seq[ 2 ] == 'C')
		{
			printf("ATC present !\n");
		}
		else
		{
			printf("ATC not present!\n");
		}
	
}


