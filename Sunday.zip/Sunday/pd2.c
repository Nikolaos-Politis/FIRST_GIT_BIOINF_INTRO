#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
	char seq[ 1000 ];
	int len;
	int i;
	int charge = 0;

	scanf("%s", seq);
	len = strlen( seq );
	printf("The length was : %d \n", len);

		if (len < 3)
		{
			printf("Eisai boubounas!!!\n");
		}
		
		if( seq[ len - 3 ] == 'T' && seq[ len - 2 ] == 'A' && seq[ len - 1 ] == 'A')
		{
			printf("ATC present !\n");
		}
		else
		{
			printf("ATC not present!\n");
		}
	
}


